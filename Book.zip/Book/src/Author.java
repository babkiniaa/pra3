 public class Author {
    private String name, pol, email;
    public Author(String name, String pol, String email){
        this.name = name;
        this.pol = pol;
        this.email = email;

    }
    public String toString(){
        return "Имя автора: " + this.name + ",, "
                + " Пол автора : " + this.pol + ",,"
                + " email автора : " + this.email;
    }
}
