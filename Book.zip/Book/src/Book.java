import java.util.Scanner;

public class Book {
    private Author author;
    private String title;
    private int years;

    public Book(String title, int years, Author author) {
        this.title = title;
        this.years = years;
        this.author = author;
    }
    public Book(){

    }
    public String toString(){
        return "Книга называется : " + this.title + ",, "
                + " Книга была издана в : " + this.years;
    }
}