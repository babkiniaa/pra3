import java.util.Scanner;
public class Main {
        public static void main(String[] args) {
            Scanner in = new Scanner (System.in );
            String title;
            int years;
            System.out.println("Введите название книги");
            title = in.nextLine();
            System.out.println("Введите год издания книги");
            years = in.nextInt();
            Book Bo = new Book(title, years, null);
            System.out.println(Bo);

            String name,pol,email;
            System.out.println("Введите имя автора");
            name = in.next();
            System.out.println("Введите пол автора");
            pol =  in.next();;
            System.out.println("Введите email автора");
            email =  in.next();;
            Author au = new Author(name, pol, email);
            System.out.println(au);
    }
}
