import java.util.Scanner;
public class cirecle {
    public int radius;
    public String color;
    public cirecle(int rad, String col) {
        radius = rad;
        color = col;
    }
    public void Area() {
            System.out.println("Площадь круга = " + (radius * radius * 3.14));
        }

    public void Perimetr() {
            System.out.println("Периметр круга = " + (2 * radius * 3.14));
        }

    public String toString() {
        return "Радиус : " + this.radius + ",, "
                + " Цвет : " + this.color;
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int rad;
        String color;
        System.out.println("Введите радиус : ");
        rad = in.nextInt();
        System.out.println("Введите цвет : ");
        color = in.next();
        cirecle ci = new cirecle(rad,color);
        ci.Area();
        ci.Perimetr();
        System.out.println(ci);

    }
}
