import javax.swing.text.Style;
import java.util.Scanner;
public class Phone {
    public int number, weight;
    public String model, name = "Patrik";

    public Phone(int num, String mod, int wei) {
        this.number = num;
        this.model = mod;
        this.weight = wei;

    }
    public Phone(int num, String mod){
        this.model = mod;
        this.number = num;
    }
    public Phone(){}
    public void receiveCall(String name) {
            System.out.println("Имя звонящего " + name);
        }

    public String toString(){
        return "Номер : " + this.number + ",, "
                + " Вес телефона : " + this.weight + ",,"
                + "Модель : " + this.model + ",,"
                + "Имя : " + this.name;
    }
    public int getNumber() {
        return number;
        }
    public void receiveCall(int number, String name){
        System.out.println("Номер звонящего " + number + " Имя звонящего " + name);
    }

    public void sendMessange(int mass[]){
        for(int i=0; i<mass.length; i++){
            System.out.println(mass[i]);
        }
    }
    public static void main(String [] args){
        Scanner in = new Scanner(System.in);
        int number, weight;
        String model;

        System.out.println("Введите номер 1 телфона ");
        number = in.nextInt();
        System.out.println("Введите модель телфона ");
        model = in.next();
        System.out.println("Введите вес телфона ");
        weight = in.nextInt();
        Phone ph = new Phone(number,model,weight);
        System.out.println(ph.number + " " + ph.model + " " + ph.weight);
        System.out.println();

        ph.receiveCall("Polka");
        System.out.println();

        ph.getNumber();
        System.out.println();
        ph.receiveCall(ph.number, ph.name);

        System.out.println(ph);

        int n;
        System.out.println("Введите количество номеров");
        n = in.nextInt();;
        int[] mass = new int[n];
        for (int i = 0; i<n;i++) {
            mass[i]=in.nextInt();;

        }
        ph.sendMessange(mass);
    }
}
